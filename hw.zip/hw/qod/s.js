fetch("https://quotes.rest/qod" ,{
    method:'POST',
    headers:{
        'content-type': 'application/json'
    },
    body: JSON.stringify({
        name: 'User 1'
    })
}).then(res => {
    return res.json()
})
.then(data => console.log(data))
.catch(error => console.log(error))
